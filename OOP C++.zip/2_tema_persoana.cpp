#include <iostream>
#include <cstring>

using namespace std;

/*
   1. Sa se defineasca o clasa "Persoana" avand campurile "nume", "prenume" si "varsta"
      si scrieti metodele de tip getter si setter pentru aceste campuri.
   2. Sa se declare 2 obiect de tip "Persoana".
      Pentru prima persoana folositi metodele de tip getter pentru a citi de la tastatura atributele
      Pentru a doua persoana folositi metodele de tip setter pentru a seta valorile atributelor
   3. Afisati informatiile despre cele 2 persoane :)

*/


class persoana   // nume clasa
{


};


int main ()
{





}
