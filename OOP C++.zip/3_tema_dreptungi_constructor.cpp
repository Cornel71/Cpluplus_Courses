#include <iostream>

using namespace std;

/*
   1. Sa se defineasca o clasa "Dreptunghi" avand campurile "lungime" si "latime" ,
   constructorul si o funtie membru pentru calculul ariei.
   2. Sa se construiasca 2 obiecte de tip "Dreptunghi" si sa se calculeze aria lor.
*/

