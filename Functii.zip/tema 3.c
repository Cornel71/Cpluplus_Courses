/*
Scrieti si utilizati intr-un program C o functie care sa determine valoarea maxima a elementelor impare
ce fac parte dintr-un vector de numere naturale. Numarul de elemente din vector si valorile acestuia se
citesc de la tastatura, in afara functiei. Exemplu: pentru 3 8 1 7 2 rezultatul este 7.

*/

#include <stdio.h>


int main()
{



    return 0;
}
