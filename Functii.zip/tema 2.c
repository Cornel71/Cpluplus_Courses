/*
Sa se scrie si sa se testeze o functie C care, analizand 3 valori numerice intregi, sa verifice daca
acestea sunt ordonate crescator, descrescator, sunt identice sau sunt neordonate (tinand cont de
ordinea in care au fost precizate).
Rezultatul va fi furnizat ca valoare de tip caracter: �C�, �D�, �I� sau �N�.
Se recomanda testarea functiei in cadrul unui program C care sa permita executia in bucla, pentru mai
multe seturi de cate 3 valori introduse de la tastatura
Alta varianta de enunt: rezultatul va fi furnizat ca valoare de tip intreg, cu
semnificatie prestabilita.
*/

#include <stdio.h>


int main()
{



    return 0;
}
