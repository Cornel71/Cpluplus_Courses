/*
Scrieti o functie care determina daca un numar este perfect.
Numarul perfect este un numar intreg egal cu suma divizorilor sai, din care se exclude numarul insusi.
Ex. 6=1+2+3; 28=1+2+4+7+14
*/

#include <stdio.h>


int main()
{



    return 0;
}
