#include <iostream>

int main( )
{
    using namespace std;

    char ch;        // declarea unei variabile de tip caracter

    cout << "Introduceti un caracter." << endl;
    cin >> ch;

    cout << "Buna! ";
    cout << "Ai introdus caracterul " << ch << "." << endl;

    return 0;
}
