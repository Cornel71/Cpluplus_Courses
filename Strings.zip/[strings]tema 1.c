/*
* Cititi de la tastatura numele si varstele a 2 persoane. Verificati daca numele introduse sunt diferite.
* Daca au nume diferite afisati numele celei mai tinere persoane.
* Daca au nume diferite si aceeasi varsta, afisati varsta lor.
* Daca au nume identice afisati un mesaj corespunzator.
* Autor: Iulia Iacob
*/


#include<stdio.h>
#include<string.h>

int main()
{
    char nume1[10], nume2[10];
    int varsta1, varsta2;

    // introduceti codul aici

    return 0;
}
