/*
* Cititi de la tastatura un text scris cu litere mici si spatii. Determinati si afisati pe ecran numarul de cuvinte.
* Autor: Iulia Iacob
*/


#include<stdio.h>
#include<string.h>



int main()
{
    char sir[100], original [100], delimitator[]=" ";
    char *token;
    int nrCuvinte=0;

   // introduceti codul aici


    return 0;
}

