/**
 *  La un concurs de gimnastica trebuie inregistrate datele a n concurenti. Pentru fiecare concurent se retine: numele,
 * varsta, rezultatele obtinute la 2 probe (punctaje <= 100) si punctajul general (acesta se calculeaza, prin
 * insumarea punctajelor obtinute la cele 2 probe). Realizati clasamentul concurentilor si stabiliti cine primeste premiile
 * I, II si III. Considerati ca, in cazul in care mai multi concurenti au punctaje egale, toti vor obtine acelasi premiu iar
 * afisarea informatiilor despre ei (la un acelasi premiu) se va face in ordine crescatoare, dupa varsta (ca sa fie motivati
 * suplimentar cei mai tineri dintre participanti).
 *
 * Implementati folosind structuri
 */

#include <stdio.h>

int main()
{


    return 0;
}
