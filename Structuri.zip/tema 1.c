/**
 * Se defineste un tip structura student cu campurile nume, nota1, nota2, nota3, care reprezinta numele
studentului si notele obtinute la 3 materii distincte (aceleasi 3 materii si in aceeasi ordine pentru toti
studentii).

Se cere:
Var 1:
a) Cititi de la tastatura datele pentru max 5 studenti de tipul struct student
b) Cautati un student dupa nume (precizat de la tastatura). Daca il gasiti, afisati toate informatiile
   care il caracterizeaza; altfel, afisati un mesaj corespunzator;
c) Aflati care este cel mai bun student la o anumita materie (precizata de la tastatura) si afisati
   numele sau. Daca exista mai multi astfel de studenti, afisati numele tuturor in ordine alfabetica.
d) Determinati si afisati numele studentilor nepromovati.

Var 2
a) Declarati un vector (tablou unidimensional) studenti de tipul struct student in care stocati
   datele despre 5-6 studenti, citite de la tastatura;
b) Cautati un student dupa nume (precizat de la tastatura). Daca il gasiti, afisati toate informatiile
   care il caracterizeaza; altfel, afisati un mesaj corespunzator;
c) Aflati care este cel mai bun student la o anumita materie (precizata de la tastatura) si afisati
   numele sau. Daca exista mai multi astfel de studenti, afisati numele tuturor in ordine alfabetica.
d) Determinati premiantul/premiantii grupului de studenti (cel/cei cu media generala maxima si
   afisati numele sau. Daca exista mai multi astfel de studenti, afisati numele tuturor.
e) Sortati vectorul studenti descrescator, in functie de valorea c�mpului nota2.
f) Determinati si afisati numele studentilor nepromovati.
 */

#include <stdio.h>

int main()
{


    return 0;
}
